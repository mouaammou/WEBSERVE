# Simple Chat UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/sajadhsm/pen/odaBdd](https://codepen.io/sajadhsm/pen/odaBdd).

Simple Chat UI with a stupid bot randomly respond to your messages!